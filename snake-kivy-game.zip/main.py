from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.clock import Clock
from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle
from random import randint


class MainMenu(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', spacing=20, padding=50)
        start_btn = Button(text="Start", font_size=40)
        exit_btn = Button(text="Exit", font_size=40)
        start_btn.bind(on_release=lambda x: setattr(self.manager, 'current', "game"))
        exit_btn.bind(on_release=lambda x: App.get_running_app().stop())
        layout.add_widget(start_btn)
        layout.add_widget(exit_btn)
        self.add_widget(layout)


class GameOver(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', spacing=20, padding=50)
        restart_btn = Button(text="Restart", font_size=40)
        back_btn = Button(text="Back", font_size=40)
        restart_btn.bind(on_release=lambda x: self.manager.get_screen("game").restart_game())
        restart_btn.bind(on_release=lambda x: setattr(self.manager, 'current', "game"))
        back_btn.bind(on_release=lambda x: setattr(self.manager, 'current', "menu"))
        layout.add_widget(Label(text="Game Over", font_size=50))
        layout.add_widget(restart_btn)
        layout.add_widget(back_btn)
        self.add_widget(layout)


class SnakeGame(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.game_widget = SnakeWidget()
        self.add_widget(self.game_widget)

    def on_enter(self):
        self.game_widget.start_game()

    def restart_game(self):
        self.clear_widgets()
        self.game_widget = SnakeWidget()
        self.add_widget(self.game_widget)
        self.game_widget.start_game()


class SnakeWidget(Widget):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.snake = [(5, 5)]
        self.food = (10, 10)
        self.direction = (1, 0)
        self.cell_size = 20
        self.game_over = False

    def start_game(self):
        Clock.schedule_interval(self.update, 0.2)

    def on_touch_up(self, touch):
        dx = touch.x - touch.opos[0]
        dy = touch.y - touch.opos[1]
        if abs(dx) > abs(dy):
            self.direction = (1, 0) if dx > 0 else (-1, 0)
        else:
            self.direction = (0, 1) if dy > 0 else (0, -1)

    def update(self, dt):
        if self.game_over:
            return
        head_x, head_y = self.snake[0]
        new_head = (head_x + self.direction[0], head_y + self.direction[1])

        if new_head in self.snake or not (0 <= new_head[0] < self.width/self.cell_size) or not (0 <= new_head[1] < self.height/self.cell_size):
            self.game_over = True
            App.get_running_app().root.current = "gameover"
            return

        self.snake.insert(0, new_head)
        if new_head == self.food:
            self.food = (randint(0, int(self.width/self.cell_size)-1), randint(0, int(self.height/self.cell_size)-1))
        else:
            self.snake.pop()

        self.draw()

    def draw(self):
        self.canvas.clear()
        with self.canvas:
            Color(0, 1, 0)
            for x, y in self.snake:
                Rectangle(pos=(x*self.cell_size, y*self.cell_size), size=(self.cell_size, self.cell_size))
            Color(1, 0, 0)
            Rectangle(pos=(self.food[0]*self.cell_size, self.food[1]*self.cell_size), size=(self.cell_size, self.cell_size))


class SnakeApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(MainMenu(name="menu"))
        sm.add_widget(SnakeGame(name="game"))
        sm.add_widget(GameOver(name="gameover"))
        return sm


if __name__ == "__main__":
    SnakeApp().run()
